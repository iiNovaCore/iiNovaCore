const { REST } = require('@discordjs/rest');
const { Routes } = require('discord-api-types/v9');
const { MessageEmbed } = require('discord.js');
const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));
const Url = 'https://random-word-api.herokuapp.com/word';
var Jimp = require("jimp");
var fs = require('fs'),
    http = require('http'),
    https = require('https');
const commands = [{
    name: 'ping',
    description: 'Replies with Pong!'
    
},
{
    name: 'cat',
    description: 'Generates an AI cat meme!'
    }
];


function genRand(max = 150000) {
    return Math.floor(Math.random() * max);
}

var Stream = require('stream').Transform;
var downloadImageFromURL = (url, filename, callback) => {



    var client = http;

    if (url.toString().indexOf("https") === 0) {
        client = https;
    }

    client.request(url, function (response) {
        var data = new Stream();
        response.on('data', function (chunk) {
            data.push(chunk);
        });

        response.on('end', function () {
            fs.writeFileSync(filename, data.read());
        });

    }).end();

};


    
const rest = new REST({ version: '9' }).setToken('OTcxNDIyMjk1NjM1NjY0OTI2.YnKRgw.0AkxIt7LoEVquM8HgJLZh774zKA');

(async () => {

   

    try {
        console.log('Started refreshing application (/) commands.');

        await rest.put(
            Routes.applicationCommands("971422295635664926"),
            { body: commands },
        );

        console.log('Successfully reloaded application (/) commands.');
    } catch (error) {
        console.error(error);
    }

    const { Client, Intents } = require('discord.js');
    const client = new Client({ intents: [Intents.FLAGS.GUILDS] });

    client.on('ready', () => {
        console.log(`Logged in as ${client.user.tag}!`);
    });
        client.on('interactionCreate', async interaction => {

           

        
        if (!interaction.isCommand()) return;
        

        
            if (interaction.commandName === 'cat') {

                await interaction.reply("Sending image...");
               
                downloadImageFromURL('https://www.thiscatdoesnotexist.com', 'cat.jpg');

                var words = fs.readFileSync('./wordlist.json', 'utf8');

                var imageCaption = (JSON.parse(words)[genRand(178187)]);

                console.log("Type of imageCaption: ", typeof imageCaption)
                var fileName = 'cat.jpg';
                var loadedImage;

                await Jimp.read(fileName)
                    .then(function (image) {
                        console.log("Loading image and font");
                        loadedImage = image;
                        return Jimp.loadFont(Jimp.FONT_SANS_32_WHITE);
                    })
                    .then(function (font) {
                        console.log("Making caption");
                        loadedImage.print(font, 220, 40, imageCaption)
                            .write(fileName);
                    })
                    .catch(function (err) {
                        console.error(err);
                    });

                console.log("'Should' be done making image");



                var embed = new MessageEmbed()

                    .setColor('00FF00')
                    .setTitle('Cat')

                    .addField('Inline field title', 'Some value here', true)
                    .setImage('attachment://cat.jpg')
                    .setTimestamp()
                    .setFooter({ text: 'Generated from thiscatdoesnotexist.com', iconURL: 'https://i.imgur.com/0aQAitF.jpg' })
                await interaction.editReply({ embeds: [embed], files: ['./cat.jpg'] } );
                await fs.rm('./cat.jpg', (err) => { if (err) throw err; });
           
        }

        if (interaction.commandName === 'ping') {
            await interaction.reply('Pong! ');
        }
        
    });

    client.login('OTcxNDIyMjk1NjM1NjY0OTI2.YnKRgw.0AkxIt7LoEVquM8HgJLZh774zKA');


})();